import time
import os
import requests


def get_image(url, save_imgPath):
    try:
        r = requests.get(url)
        print(r)
        with open(save_imgPath, 'wb') as f:
            f.write(r.content)
    except requests.exceptions.ConnectionError as e:
        time.sleep(5)
        requests.status_codes = "Connection refused"
        print(e)


def save_txt(txt_path, infos):
    with open(txt_path, 'a+', encoding='utf-8') as f:
        f.writelines(infos)


def writeNewLines(txt_path, dir_path, save_txtPath):
    jpg_list = list(os.listdir(dir_path))
    new_lines = []
    with open(txt_path, 'r', encoding='utf-8') as f:
        datas = f.readlines()
        for line in datas:
            jpg = line.strip().split(":")[0]
            if jpg in jpg_list:
                print(line)
                new_lines.append(line)

    with open(save_txtPath, 'w', encoding='utf-8') as fw:
        fw.writelines(new_lines)

def reWriteTxtInfos(dir_rootPath):
    dir_list = []
    for file in os.listdir(dir_rootPath):
        if file.startswith("imgs_"):
            dir_path = os.path.join(dir_rootPath, file)
            print(dir_path)
            txt_path = os.path.join(dir_rootPath, "描述_{}.txt".format(file))
            new_txt_path = os.path.join(dir_rootPath, "ok_{}.txt".format(file))
            writeNewLines(txt_path, dir_path, new_txt_path)


if __name__ == '__main__':
    root_path = r"E:\workInHome"
    reWriteTxtInfos(root_path)

