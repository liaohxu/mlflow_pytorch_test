import os


TAG_DIRS = [
    'imgs_灌木丛_植物',
    'imgs_停车棚_车位',
]


def removeLog(dir_path):
    for file in os.listdir(dir_path):
        if file.endswith(".log"):
            file_path = os.path.join(dir_path, file)
            os.remove(file_path)


def reNameFiles(dir_path):
    for file in os.listdir(dir_path):
        if "(" in file:
            print(file)
            file_path = os.path.join(dir_path, file)
            new_name = file.replace(" ", "").replace("(", "_").replace(")", "")
            new_fpath = os.path.join(dir_path, new_name)
            os.rename(file_path, new_fpath)


def matchAndWrite(dir_path):
    one_dirTxtInfos = []
    for log in sorted(os.listdir(dir_path)):
        if log.endswith(".log"):
            log_path = os.path.join(dir_path, log)
            with open(log_path, 'r', encoding='utf-8') as f:
                line = f.readlines()[0]
                info = line.strip().split(":")[1]
                pres = log.split(".log")[0].split(".")

                rst = pres[0] + ".jpg"
                if len(pres[1]) > 3:
                    rst = pres[0] + pres[1][3:] + ".jpg"
                one_ln = rst + ":" + info + "\n"
                one_dirTxtInfos.append(one_ln)
    return one_dirTxtInfos
            

def mergeTxtInfos(dir_rootPath):
    for file in os.listdir(dir_rootPath):
        if file.startswith("imgs_"):
            file_path = os.path.join(dir_rootPath, file)
            print(file_path)
            reNameFiles(file_path)
            one_dirTxtInfos = matchAndWrite(file_path)

            save_txtPath = os.path.join(dir_rootPath, "ok_{}.txt".format(file))
            with open(save_txtPath, 'w', encoding='utf-8') as fw:
                fw.writelines(one_dirTxtInfos)

            # 删除文件夹内无效的 txt文件
            removeLog(file_path)


def oneWrite(txt_path, dir_path):
    with open(txt_path, 'r', encoding='utf-8') as f:
        datas = f.readlines()
        for ln in datas:
            jpg = ln.strip().split(":")[0]
            new_txtPath = os.path.join(dir_path, jpg+".log")

            with open(new_txtPath, 'w', encoding='utf-8') as fw:
                fw.write(ln)


def splitTxtInfos(dir_rootPath):
    for file in os.listdir(dir_rootPath):
        if file.startswith("ok_"):
            file_path = os.path.join(dir_rootPath, file)
            dir_path = os.path.join(dir_rootPath, file.split(".txt")[0].split("ok_描述_")[-1])
            print(f'txt_path= {file_path}')
            oneWrite(file_path, dir_path)


def writeNewLines(txt_path, dir_path, save_txtPath):
    jpg_list = list(os.listdir(dir_path))
    new_lines = []
    with open(txt_path, 'r', encoding='utf-8') as f:
        datas = f.readlines()
        for line in datas:
            jpg = line.strip().split(":")[0]
            if jpg in jpg_list:
                print(line)
                new_lines.append(line)

    with open(save_txtPath, 'w', encoding='utf-8') as fw:
        fw.writelines(new_lines)


def reWriteTxtInfos(dir_rootPath):
    for file in os.listdir(dir_rootPath):
        if file.startswith("imgs_"):
        # if file.startswith("imgs_") and file in TAG_DIRS:
            dir_path = os.path.join(dir_rootPath, file)
            print(dir_path)
            txt_path = os.path.join(dir_rootPath, "描述_{}.txt".format(file))
            new_txt_path = os.path.join(dir_rootPath, "ok_{}.txt".format(file))
            # new_txt_path = os.path.join(dir_rootPath, "ok_描述_{}.txt".format(file))
            writeNewLines(txt_path, dir_path, new_txt_path)


def readTxt(txt_path):
    ln_dict = {}
    with open(txt_path, 'r', encoding='utf-8') as f:
        datas = f.readlines()
        for line in datas:
            jpg = line.strip().split(":")[0]
            ln_dict[jpg] = line
    return ln_dict


def getLineInfo(ln_dict, jpgs):
    infos = []
    for jpg in sorted(jpgs, key=lambda x: "{0:0>8}".format(x.split(".jpg")[0])):
        infos.append(ln_dict.get(jpg))
    return infos


def writeToTxt(dir_path, ln_dict, rst_dict):
    for key in rst_dict:
        nTxt_Path = os.path.join(dir_path, f"ok_{key}.txt")
        infos = getLineInfo(ln_dict, rst_dict.get(key))

        with open(nTxt_Path, 'w', encoding='utf-8') as fw:
            fw.writelines(infos)


def getJpgList(dir_path):
    rst_dict = {}
    for root, dirs, files in os.walk(dir_path):
        for fl in files:
            if fl.endswith(".jpg"):
                fl_path = os.path.join(root, fl)
                dir_name = os.path.basename(os.path.dirname(fl_path))
                if dir_name in rst_dict:
                    rst_dict[dir_name].append(fl)
                else:
                    rst_dict[dir_name] = [fl]
    return rst_dict


def reWriteSplitTxtInfos(dir_rootPath):
    for file in os.listdir(dir_rootPath):
        if file.startswith("imgs_"):
            dir_path = os.path.join(dir_rootPath, file)
            print(dir_path)
            txt_path = os.path.join(dir_rootPath, "ok_{}.txt".format(file))

            # 读txt
            ln_dict = readTxt(txt_path)
            # 匹对图片和txt
            rst_dict = getJpgList(dir_path)
            # 写txt
            writeToTxt(dir_path, ln_dict, rst_dict)


if __name__ == '__main__':
    root_path = r"E:\workInHome\test"
    # reWriteTxtInfos(root_path)
    # splitTxtInfos(root_path)
    # mergeTxtInfos(root_path)

    reWriteSplitTxtInfos(root_path)
