import os


def readTxt(txt_path):
    ln_dict = {}
    with open(txt_path, 'r', encoding='utf-8') as f:
        datas = f.readlines()
        for line in datas:
            jpg = line.strip().split(":")[0]
            ln_dict[jpg] = line
    return ln_dict


def getLineInfo(ln_dict, jpgs):
    infos = []
    for jpg in sorted(jpgs, key=lambda x: "{0:0>8}".format(x.split(".jpg")[0])):
        infos.append(ln_dict.get(jpg))
    return infos


def writeToTxt(dir_path, ln_dict, rst_dict):
    for key in rst_dict:
        nTxt_Path = os.path.join(dir_path, f"ok_{key}.txt")
        infos = getLineInfo(ln_dict, rst_dict.get(key))

        with open(nTxt_Path, 'w', encoding='utf-8') as fw:
            fw.writelines(infos)


def getJpgList(dir_path):
    rst_dict = {}
    for root, dirs, files in os.walk(dir_path):
        for fl in files:
            if fl.endswith(".jpg"):
                fl_path = os.path.join(root, fl)
                dir_name = os.path.basename(os.path.dirname(fl_path))
                if dir_name in rst_dict:
                    rst_dict[dir_name].append(fl)
                else:
                    rst_dict[dir_name] = [fl]
    return rst_dict


def reWriteSplitTxtInfos(dir_rootPath):
    for file in os.listdir(dir_rootPath):
        if file.startswith("imgs_"):
            dir_path = os.path.join(dir_rootPath, file)
            print(dir_path)
            txt_path = os.path.join(dir_rootPath, "ok_{}.txt".format(file))

            if not os.path.exists(txt_path):
                txt_path = os.path.join(dir_rootPath, "描述_{}.txt".format(file))

            # 读txt
            ln_dict = readTxt(txt_path)
            # 匹对图片和txt
            rst_dict = getJpgList(dir_path)
            # 写txt
            writeToTxt(dir_path, ln_dict, rst_dict)


if __name__ == '__main__':
    root_path = r"E:\workInHome\results_0419_分类\results_0408"
    reWriteSplitTxtInfos(root_path)
